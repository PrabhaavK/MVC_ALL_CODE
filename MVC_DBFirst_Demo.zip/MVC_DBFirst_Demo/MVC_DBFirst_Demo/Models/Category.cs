using System;
using Microsoft.EntityFrameworkCore;

namespace MVC_DBFirst_Demo.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}